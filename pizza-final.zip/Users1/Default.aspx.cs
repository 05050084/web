﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        double ttotal=0,aa=0;
        double nno1 = Convert.ToDouble(no1.SelectedValue);  
        double nno2 = Convert.ToDouble(no2.Text);
        double nno3 = Convert.ToDouble(no3.Text);
        double ccost1 = Convert.ToDouble(cost1.Text);
        double ccost2 = Convert.ToDouble(cost2.Text);
        double ccost3 = Convert.ToDouble(cost3.Text);
        string str;
        int i, j;
        tt1.Text = "";

        if (C1.Checked)
            ttotal += nno1 * ccost1 ;

        if (C2.Checked)
            ttotal += nno2 * ccost2;

        if (C3.Checked)
            ttotal += nno3 * ccost3;



        if (CB1.Items[0].Selected)
        {
            ttotal = ttotal + 30;
            tt1.Text = tt1.Text + "\r\n" + CB1.Items[0].Value;
        }
        if (CB1.Items[1].Selected)
        {
            ttotal = ttotal + 30;
            tt1.Text = tt1.Text + "\r\n" + CB1.Items[1].Value;
        }
        if (CB1.Items[2].Selected)
        {
            ttotal = ttotal + 40;
            tt1.Text = tt1.Text + "\r\n" + CB1.Items[2].Value;
        }
        if (CB1.Items[3].Selected)
        { 
            ttotal = ttotal + 10;
            tt1.Text = tt1.Text + "\r\n" + CB1.Items[3].Value;
            }
        total.Text = Convert.ToString(ttotal);
        if (CP1.Text == CP2.Text)
        {
            aa = ttotal;
            aa = aa * 0.8;
            total2.Text = Convert.ToString(aa);
        }
      if(CP1.Text=="")
            total2.Text = Convert.ToString("");

        if (R1.SelectedValue == "1")
            L1.Text = R1.SelectedItem.Text;

        if (R1.SelectedValue == "3")
            L1.Text = R1.SelectedItem.Text;

        if (R1.SelectedValue == "5")
            L1.Text = R1.SelectedItem.Text;

        if (R1.SelectedValue == "7")
            L1.Text = R1.SelectedItem.Text;

        if (R1.SelectedValue == "10")
            L1.Text = R1.SelectedItem.Text;

         
        

        if (LB.Items[0].Selected)
            tt1.Text = tt1.Text + "\r\n" +   LB.Items[0].Text ;
        
        if (LB.Items[1].Selected)
             tt1.Text = tt1.Text + "\r\n"  +  LB.Items[1].Text;

        if (LB.Items[2].Selected)
            tt1.Text = tt1.Text + "\r\n" + LB.Items[2].Text;

        if (LB.Items[3].Selected)
            tt1.Text = tt1.Text + "\r\n" + LB.Items[3].Text;

 
    }

    protected void te1_TextChanged(object sender, EventArgs e)
    {
        te2.Text = te1.Text;
    }



    protected void cost1_TextChanged(object sender, EventArgs e)
    {
        double nno1 = Convert.ToDouble(no1.SelectedValue);
       
        double ccost1 = Convert.ToDouble(cost1.Text);
        

        Label8.Text = Convert.ToString( nno1 * ccost1);
    }

    protected void cost2_TextChanged(object sender, EventArgs e)
    {
       
        double nno2 = Convert.ToDouble(no2.Text);
        
        double ccost2 = Convert.ToDouble(cost2.Text);
        
        Label9.Text = Convert.ToString(nno2 * ccost2);
    }

    protected void cost3_TextChanged(object sender, EventArgs e)
    {
       
        double nno3 = Convert.ToDouble(no3.Text);
        
        double ccost3 = Convert.ToDouble(cost3.Text);
        Label10.Text = Convert.ToString(nno3 * ccost3);
    }


   
}